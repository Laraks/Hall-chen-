document.addEventListener('DOMContentLoaded', function () {
  const blogContainer = document.getElementById('blogContainer');

  fetch('dummy.json')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      data.blogposts.forEach(post => {
        const truncatedText = post.text.length > 150 ? post.text.substring(0, 147) + '...' : post.text;

        const blogCard = document.createElement('div');
        blogCard.classList.add('blog-card');

        const blogTitle = document.createElement('h2');
        blogTitle.textContent = post.title;
        blogCard.appendChild(blogTitle);

        const blogText = document.createElement('p');
        blogText.textContent = truncatedText;
        blogCard.appendChild(blogText);

        blogContainer.appendChild(blogCard);
      });
    })
    .catch(error => console.error('Error loading blogposts:', error));
});
