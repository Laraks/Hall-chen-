// Formelvalidierung
function validateForm() {
  let vorname = document.getElementById('vorname').value;
  let nachname = document.getElementById('nachname').value;
  let adresse = document.getElementById('adresse').value;
  let plz = document.getElementById('plz').value;
  let ort = document.getElementById('ort').value;
  let email = document.getElementById('email').value;
  let grund = document.getElementById('grund').value;


  if (!vorname || !nachname || !adresse || !plz || !ort || !email || !grund) {
    alert('Bitte füllen Sie alle Felder aus.');
    return false;
  }

 
  if (!/^\d{5}$/.test(plz)) {
    alert('Bitte geben Sie eine gültige Postleitzahl ein (5 Ziffern).');
    return false;
  }

 
  if (!validateEmail(email)) {
    alert('Bitte geben Sie eine gültige E-Mail-Adresse ein.');
    return false;
  }

  // if good = send
  return true;
}

function validateEmail(email) {
  let re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// Slider...
const slider = document.querySelector('.slider');
const slides = slider.querySelectorAll('img');

let currentSlide = 0;
let isPlaying = true;
let slideInterval;

function showSlide(index) {
  slides.forEach((slide, i) => {
    if (i === index) {
      slide.style.display = 'block';
    } else {
      slide.style.display = 'none';
    }
  });
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

function prevSlide() {
  currentSlide = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(currentSlide);
}

function pausePlaySlide() {
  if (isPlaying) {
    clearInterval(slideInterval);
  } else {
    slideInterval = setInterval(nextSlide, 3000);
  }
  isPlaying = !isPlaying;
}

showSlide(currentSlide);
slideInterval = setInterval(nextSlide, 3000);

document.getElementById('prevBtn').addEventListener('click', () => {
  prevSlide();
  pausePlaySlide();
});

document.getElementById('nextBtn').addEventListener('click', () => {
  nextSlide();
  pausePlaySlide();
});

document.getElementById('pausePlayBtn').addEventListener('click', () => {
  pausePlaySlide();
});
